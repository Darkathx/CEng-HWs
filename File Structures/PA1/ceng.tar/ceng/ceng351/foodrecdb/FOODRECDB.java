package ceng.ceng351.foodrecdb;


import java.sql.*;
import java.util.*;

public class FOODRECDB implements IFOODRECDB {
    public static Connection con = null;
    private static String user = "e2522134";// username;
    private static String password = "f6Is__8xE54PCNcG"; // password;
    private static String host = "momcorp.ceng.metu.edu.tr"; //"host name";
    private static String database = "db2522134";// database name;
    private static int port = 8080; // 8080;


    @Override
    public void initialize() {
        String url = "jdbc:mysql://" + this.host + ":" + this.port + "/" + this.database;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.con =  DriverManager.getConnection(url, this.user, this.password);
        }
        catch(SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    @Override
    public int createTables() {
        try (Statement stt = con.createStatement()) {
            String query1 = "CREATE TABLE MenuItems(" +
                    "itemID INT," +
                    "itemName VARCHAR(20)," +
                    "cuisine VARCHAR(20)," +
                    "price INT," +
                    "PRIMARY KEY(itemID));";
            String query2 = "CREATE TABLE Ingredients(" +
                    "ingredientID INT," +
                    "ingredientName VARCHAR(40)," +
                    "PRIMARY KEY(ingredientID));";
            String query3 = "CREATE TABLE Includes(" +
                    "itemID INT," +
                    "ingredientID INT," +
                    "PRIMARY KEY(itemID, ingredientID)," +
                    "FOREIGN KEY(itemID) REFERENCES MenuItems(itemID) ON DELETE CASCADE ON UPDATE CASCADE," +
                    "FOREIGN KEY(ingredientID) REFERENCES Ingredients(ingredientID) ON DELETE CASCADE ON UPDATE CASCADE);";
            String query4 = "CREATE TABLE Ratings(" +
                    "ratingID INT," +
                    "itemID INT," +
                    "rating INT," +
                    "ratingDate DATE," +
                    "PRIMARY KEY(ratingID)," +
                    "FOREIGN KEY(itemID) REFERENCES MenuItems(itemID) ON DELETE CASCADE ON UPDATE CASCADE);";
            String query5 = "CREATE TABLE DietaryCategories(\n" +
                    "ingredientID INT,\n" +
                    "dietaryCategory VARCHAR(20),\n" +
                    "PRIMARY KEY(ingredientID, dietaryCategory),\n" +
                    "FOREIGN KEY(ingredientID) REFERENCES Ingredients(ingredientID) ON DELETE CASCADE ON UPDATE CASCADE);";
            stt.execute(query1);
            stt.execute(query2);
            stt.execute(query3);
            stt.execute(query4);
            stt.execute(query5);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN createTables");
        }
        return 5;
    }

    @Override
    public int dropTables() {
        int result = 0;
        String query1 = "DROP TABLE IF EXISTS MenuItems;";
        String query2 = "DROP TABLE IF EXISTS Ingredients;";
        String query3 = "DROP TABLE IF EXISTS Includes;";
        String query4 = "DROP TABLE IF EXISTS Ratings;";
        String query5 = "DROP TABLE IF EXISTS DietaryCategories;";
        try {
            Statement stt = con.createStatement();
            result += stt.executeUpdate(query3);
            result += stt.executeUpdate(query4);
            result += stt.executeUpdate(query5);
            result += stt.executeUpdate(query1);
            result += stt.executeUpdate(query2);

        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN dropTables");
        }
        return 5;
    }

    @Override
    public int insertMenuItems(MenuItem[] items) {
        String query;
        int result = 0;
        try(Statement stt = con.createStatement()) {
            for(int i = 0; i < items.length; i++) {
                query = "INSERT INTO MenuItems VALUES (" + items[i].getItemID() + ",'" + items[i].getItemName() + "','" + items[i].getCuisine() + "'," + items[i].getPrice() + ");";
                result += stt.executeUpdate(query);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN insertMenuItems");

        }
        return result;
    }

    @Override
    public int insertIngredients(Ingredient[] ingredients) {
        String query;
        int result = 0;
        try(Statement stt = con.createStatement()) {
            for(int i = 0; i < ingredients.length; i++) {
                query = "INSERT INTO Ingredients VALUES (" + ingredients[i].getIngredientID() + ",'" + ingredients[i].getIngredientName() + "');";
                result += stt.executeUpdate(query);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN insertIngredients");
        }

        return result;
    }

    @Override
    public int insertIncludes(Includes[] includes) {
        String query;
        int result = 0;
        try(Statement stt = con.createStatement()) {
            for(int i = 0; i < includes.length; i++) {
                query = "INSERT INTO Includes VALUES (" + includes[i].getItemID() + "," + includes[i].getIngredientID() + ");";
                result += stt.executeUpdate(query);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN insertIncludes");
        }

        return result;
    }

    @Override
    public int insertDietaryCategories(DietaryCategory[] categories) {
        String query;
        int result = 0;
        try(Statement stt = con.createStatement()) {
            for(int i = 0; i < categories.length; i++) {
                query = "INSERT INTO DietaryCategories VALUES (" + categories[i].getIngredientID() + ",'" + categories[i].getDietaryCategory() + "');";
                result += stt.executeUpdate(query);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN insertDietaryCategories");
        }

        return result;
    }

    @Override
    public int insertRatings(Rating[] ratings) {
        String query;
        int result = 0;
        try(Statement stt = con.createStatement()) {
            for(int i = 0; i < ratings.length; i++) {
                String toConvert = ratings[i].getRatingDate();
                query = "INSERT INTO Ratings VALUES (" + ratings[i].getRatingID() + "," + ratings[i].getItemID() + "," + ratings[i].getRating() + ", '" + toConvert +  "');";
                result += stt.executeUpdate(query);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN insertRatings");
        }

        return result;
    }

    @Override
    public MenuItem[] getMenuItemsWithGivenIngredient(String name) {
        MenuItem[] result = null;
        String query = "SELECT M.itemID, M.itemName, M.cuisine, M.price " +
                "FROM MenuItems M, Includes Ic, Ingredients Ig " +
                "WHERE Ic.itemID = M.itemID AND Ic.ingredientID = Ig.ingredientID AND Ig.ingredientName = '" + name + "' " +
                "ORDER BY M.itemID ASC";
        try (Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            List<MenuItem> list = new ArrayList<MenuItem>();
            MenuItem Item;
            while(rs.next()) {
                int itemID = rs.getInt("M.itemID");
                String itemName = rs.getString("M.itemName");
                String itemCuisine = rs.getString("M.cuisine");
                int itemPrice = rs.getInt("M.price");
                Item = new MenuItem(itemID, itemName, itemCuisine, itemPrice);
                list.add(Item);
            }
            result = new MenuItem[list.size()];
            result = list.toArray(result);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMenuItemsWithGivenIngredient");
        }

        return result;
    }

    @Override
    public MenuItem[] getMenuItemsWithoutAnyIngredient() {

        MenuItem[] result = null;
        String query = "SELECT M.itemID, M.itemName, M.cuisine, M.price\n" +
                "FROM MenuItems M\n" +
                "WHERE M.itemID NOT IN(\n" +
                "SELECT M2.itemID\n" +
                "FROM MenuItems M2, Includes I\n" +
                "WHERE M2.itemID = I.itemID)\n" +
                "ORDER BY M.itemID ASC";
        try (Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            List<MenuItem> list = new ArrayList<MenuItem>();
            MenuItem Item = null;
            while(rs.next()) {
                int itemID = rs.getInt("M.itemID");
                String itemName = rs.getString("M.itemName");
                String itemCuisine = rs.getString("M.cuisine");
                int itemPrice = rs.getInt("M.price");
                Item = new MenuItem(itemID, itemName, itemCuisine, itemPrice);
                list.add(Item);
            }
            result = new MenuItem[list.size()];
            result = list.toArray(result);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMenuItemsWithoutAnyIngredient");
        }

        return result;
    }

    @Override
    public Ingredient[] getNotIncludedIngredients() {
        Ingredient[] result = null;
        String query = "SELECT *\n" +
                "FROM Ingredients I\n" +
                "WHERE I.ingredientID NOT IN(\n" +
                "SELECT I2.ingredientID\n" +
                "FROM Ingredients I2, Includes IC\n" +
                "WHERE I2.ingredientID = IC.ingredientID)\n" +
                "ORDER BY I.ingredientID ASC;";
        try (Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            List<Ingredient> list = new ArrayList<Ingredient>();
            Ingredient ing = null;
            while(rs.next()) {
                int ingredientID = rs.getInt("I.ingredientID");
                String ingredientName = rs.getString("I.ingredientName");
                ing = new Ingredient(ingredientID, ingredientName);
                list.add(ing);
            }
            result = new Ingredient[list.size()];
            result = list.toArray(result);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getNotIncludedIngredients");
        }

        return result;
    }

    @Override
    public MenuItem getMenuItemWithMostIngredients() {
        MenuItem result = null;
        String query = "SELECT M.itemID, M.itemName, M.cuisine, M.price\n" +
                "FROM MenuItems M, Includes I\n" +
                "WHERE M.itemID = I.itemID\n" +
                "GROUP BY M.itemID, M.itemName, M.cuisine, M.price\n" +
                "HAVING COUNT(*) >= ALL (\n" +
                "SELECT COUNT(*)\n" +
                "FROM MenuItems M2, Includes I2\n" +
                "WHERE M2.itemID = I2.itemID\n" +
                "GROUP BY M2.itemID, M2.itemName, M2.cuisine, M2.price);";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            rs.next();
            result = new MenuItem(rs.getInt("M.itemID"), rs.getString("M.itemName"), rs.getString("M.cuisine"), rs.getInt("M.price"));
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMenuItemWithMostIngredients");
        }
        return result;
    }

    @Override
    public QueryResult.MenuItemAverageRatingResult[] getMenuItemsWithAvgRatings() {
        QueryResult.MenuItemAverageRatingResult[] result = null;
        List<QueryResult.MenuItemAverageRatingResult> list = new ArrayList<QueryResult.MenuItemAverageRatingResult>();
        QueryResult.MenuItemAverageRatingResult temp = null;
        String query = "SELECT M.itemID, M.itemName, AVG(R.rating) AS avgRating\n" +
                "FROM MenuItems M NATURAL LEFT OUTER JOIN Ratings R\n" +
                "GROUP BY M.itemID, M.itemName\n" +
                "ORDER BY avgRating DESC;";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            while(rs.next()) {
                String itemID = rs.getString("M.itemID");
                String itemName = rs.getString("M.itemName");
                String avgRating = rs.getString("avgRating");
                temp = new QueryResult.MenuItemAverageRatingResult(itemID, itemName, avgRating);
                list.add(temp);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMenuItemsWithAvgRatings");
        }
        result = new QueryResult.MenuItemAverageRatingResult[list.size()];
        result = list.toArray(result);
        return result;
    }

    @Override
    public MenuItem[] getMenuItemsForDietaryCategory(String category) {
        MenuItem[] result = null;
        List<MenuItem> list = new ArrayList<MenuItem>();
        MenuItem item = null;
        String query = "SELECT DISTINCT M.itemID, M.itemName, M.cuisine, M.price\n" +
                "FROM MenuItems M, Includes I\n" +
                "WHERE M.itemID = I.itemID AND M.itemID NOT IN(" +
                "SELECT DISTINCT M2.itemID\n" +
                "FROM MenuItems M2, Includes I2\n" +
                "WHERE M2.itemID = I2.itemID AND I2.ingredientID NOT IN (\n" +
                    "SELECT D.ingredientID\n" +
                    "FROM DietaryCategories D\n" +
                    "WHERE D.ingredientID = I2.ingredientID AND D.dietaryCategory = '" + category + "'))\n" +
                "ORDER BY M.itemID ASC";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            while(rs.next()) {
                int itemID = rs.getInt("M.itemID");
                String itemName = rs.getString("M.itemName");
                String itemCuisine = rs.getString("M.cuisine");
                int itemPrice = rs.getInt("M.price");
                item = new MenuItem(itemID, itemName, itemCuisine, itemPrice);
                list.add(item);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMenuItemsForDietaryCategory");
        }
        result = new MenuItem[list.size()];
        result = list.toArray(result);
        return result;
    }

    @Override
    public Ingredient getMostUsedIngredient() {
        Ingredient ing = null;
        String query = "SELECT I1.ingredientID, I1.ingredientName\n" +
                "FROM Ingredients I1, Includes Ic1\n" +
                "WHERE I1.ingredientID = Ic1.ingredientID\n" +
                "GROUP BY I1.ingredientID, I1.ingredientName\n" +
                "HAVING COUNT(*) >= ALL (\n" +
                    "SELECT COUNT(*)\n" +
                    "FROM Ingredients I2, Includes Ic2\n" +
                    "WHERE I2.ingredientID = I1.ingredientID AND I2.ingredientID = Ic2.ingredientID\n" +
                    "GROUP BY I2.ingredientID);";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            rs.next();
            int ingredientID = rs.getInt("I1.ingredientID");
            String ingredientName = rs.getString("I1.ingredientName");
            ing = new Ingredient(ingredientID, ingredientName);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getMostUsedIngredient");
        }
        return ing;
    }

    @Override
    public QueryResult.CuisineWithAverageResult[] getCuisinesWithAvgRating() {
        QueryResult.CuisineWithAverageResult[] result = null;
        List<QueryResult.CuisineWithAverageResult> list = new ArrayList<QueryResult.CuisineWithAverageResult>();
        QueryResult.CuisineWithAverageResult temp = null;
        String query = "SELECT DISTINCT M.cuisine, AVG(R.rating) AS avg\n" +
                "FROM MenuItems M NATURAL LEFT OUTER JOIN Ratings R\n" +
                "GROUP BY M.cuisine\n" +
                "ORDER BY avg DESC;";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            while(rs.next()) {
                String cuisineName = rs.getString("M.cuisine");
                String average = rs.getString("avg");
                temp = new QueryResult.CuisineWithAverageResult(cuisineName, average);
                list.add(temp);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getCuisinesWithAvgRating");
        }
        result = new QueryResult.CuisineWithAverageResult[list.size()];
        result = list.toArray(result);
        return result;
    }

    @Override
    public QueryResult.CuisineWithAverageResult[] getCuisinesWithAvgIngredientCount() {
        QueryResult.CuisineWithAverageResult[] result = null;
        List<QueryResult.CuisineWithAverageResult> list = new ArrayList<QueryResult.CuisineWithAverageResult>();
        QueryResult.CuisineWithAverageResult temp = null;
        String query = "SELECT temp.cuisine, AVG(temp.ingCount) AS avg\n" +
                "FROM (\n" +
                    "SELECT M.itemID, M.cuisine, COUNT(I.ingredientID) AS ingCount\n" +
                    "FROM MenuItems M NATURAL LEFT OUTER JOIN Includes I\n" +
                    "GROUP BY M.itemID) AS temp\n" +
                "GROUP BY temp.cuisine\n" +
                "ORDER BY avg DESC;";
        try(Statement stt = con.createStatement()) {
            ResultSet rs = stt.executeQuery(query);
            while(rs.next()) {
                String cuisineName = rs.getString("temp.cuisine");
                String average = rs.getString("avg");
                temp = new QueryResult.CuisineWithAverageResult(cuisineName, average);
                list.add(temp);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN getCuisinesWithAvgIngredientCount");
        }
        result = new QueryResult.CuisineWithAverageResult[list.size()];
        result = list.toArray(result);
        return result;
    }

    @Override
    public int increasePrice(String ingredientName, String increaseAmount) {
        int result = 0;
        String query = "UPDATE MenuItems M\n" +
                "SET M.price = M.price + " + increaseAmount + "\n" +
                "WHERE M.itemID IN(\n" +
                    "SELECT temp.itemID\n" +
                    "FROM (\n" +
                        "SELECT M2.itemID\n" +
                        "FROM MenuItems M2, Ingredients Ig, Includes Ic\n" +
                        "WHERE M2.itemID = Ic.itemID AND Ic.ingredientID = Ig.ingredientID AND Ig.ingredientName = '" + ingredientName + "') AS temp);";
        try(Statement stt = con.createStatement()) {
            result += stt.executeUpdate(query);
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN increasePrice");
        }
        return result;
    }

    @Override
    public Rating[] deleteOlderRatings(String date) {
        Rating[] result = null;
        List<Rating> list = new ArrayList<Rating>();
        Rating rt = null;
        int temp = 0;
        String query = "SELECT *\n" +
                "FROM Ratings R\n" +
                "WHERE R.ratingDate < '" + date + "'\n" +
                "ORDER BY R.ratingID ASC;";
        String query2 = "DELETE\n" +
                "FROM Ratings R\n" +
                "WHERE R.ratingDate < '" + date + "';";
        try(Statement stt = con.createStatement()) {
            Statement stt2 = con.createStatement();
            ResultSet rs = stt.executeQuery(query);
            temp += stt2.executeUpdate(query2);

            while(rs.next()) {
                int ratingID = rs.getInt("R.ratingID");
                int itemID = rs.getInt("R.itemId");
                int Rating = rs.getInt("R.rating");
                String ratingDate = rs.getString("R.ratingDate");
                rt = new Rating(ratingID, itemID, Rating, ratingDate);
                list.add(rt);
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
            System.out.println("ERROR IN deleteOlderRatings");
        }
        result = new Rating[list.size()];
        result = list.toArray(result);
        return result;
    }
}