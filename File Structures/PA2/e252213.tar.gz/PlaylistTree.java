import java.util.ArrayList;

public class PlaylistTree {

	public PlaylistNode primaryRoot;		//root of the primary B+ tree
	public PlaylistNode secondaryRoot;	//root of the secondary B+ tree
	public PlaylistTree(Integer order) {
		PlaylistNode.order = order;
		primaryRoot = new PlaylistNodePrimaryLeaf(null);
		primaryRoot.level = 0;
		secondaryRoot = new PlaylistNodeSecondaryLeaf(null);
		secondaryRoot.level = 0;
	}

	public void addSong(CengSong song) {
		// TODO: Implement this method
		// add methods to fill both primary and secondary tree
		addPrimary(song);
		addSecondary(song);

		return;
	}

	public CengSong searchSong(Integer audioId) {
		// TODO: Implement this method
		// find the song with the searched audioId in primary B+ tree
		// return value will not be tested, just print according to the specifications
		int i, tabCount = 0;
		String toPrint = "";
		PlaylistNodePrimaryLeaf tempLeaf = null;
		CengSong tempSong;
		boolean found = false;
		if(primaryRoot.getType() != PlaylistNodeType.Leaf) {
			PlaylistNodePrimaryIndex temp = (PlaylistNodePrimaryIndex) primaryRoot, prevTemp;
			while(temp.getChildrenAt(0).getType() != PlaylistNodeType.Leaf) {
				prevTemp = temp;
				for(i = 0; i < temp.audioIdCount(); i++) {
					if(audioId < temp.audioIdAtIndex(i)) {
						temp = (PlaylistNodePrimaryIndex) temp.getChildrenAt(i);
						break;
					}
				}
				if(i == temp.audioIdCount()) {
					temp = (PlaylistNodePrimaryIndex) temp.getChildrenAt(i);
				}
				toPrint = toPrint.concat("<index>\n");
				for(i = 0; i < prevTemp.audioIdCount(); i++) {
					for(int j = 0; j < tabCount; j++) {
						toPrint = toPrint.concat("\t");
					}
					toPrint = toPrint.concat(Integer.toString(prevTemp.audioIdAtIndex(i)) + "\n");
					for(int j = 0; j < tabCount; j++) {
						toPrint = toPrint.concat("\t");
					}
				}
				toPrint = toPrint.concat("</index>\n");
				tabCount++;
			}
			for(i = 0; i < temp.audioIdCount(); i++) {
				if(audioId < temp.audioIdAtIndex(i)) {
					tempLeaf = (PlaylistNodePrimaryLeaf) temp.getChildrenAt(i);
					break;
				}
			}
			if(i == temp.audioIdCount()) {
				tempLeaf = (PlaylistNodePrimaryLeaf) temp.getChildrenAt(i);
			}
			for(int j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("<index>\n");
			for(i = 0; i < temp.audioIdCount(); i++) {
				for(int j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat(Integer.toString(temp.audioIdAtIndex(i)) + "\n");
			}
			for(int j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("</index>\n");
			tabCount++;
		}
		else {
			tempLeaf = (PlaylistNodePrimaryLeaf) primaryRoot;
		}

		for(i = 0; i < tempLeaf.songCount(); i++) {
			tempSong = tempLeaf.songAtIndex(i);

			if(tempSong.audioId() == audioId) {
				for(int j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat("<data>\n");
				for(int j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat("<record>");
				toPrint = toPrint.concat(tempSong.audioId() + "|" + tempSong.genre() + "|" + tempSong.songName() + "|" + tempSong.artist());
				toPrint = toPrint.concat("</record>\n");
				for(int j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat("</data>");
				System.out.println(toPrint);
				return null;
			}

		}
		toPrint = toPrint.concat("Could not find <" + audioId + ">.");
		System.out.println(toPrint);
		return null;
	}


	public void printPrimaryPlaylist() {
		// TODO: Implement this method
		// print the primary B+ tree in Depth-first order
		printPrimaryDFS(primaryRoot, 0);

		return;
	}

	public void printSecondaryPlaylist() {
		// TODO: Implement this method
		// print the secondary B+ tree in Depth-first order
		printSecondaryDFS(secondaryRoot, 0);
		return;
	}

	// Extra functions if needed

	public void addPrimary(CengSong song) {
		int i;
		PlaylistNodePrimaryLeaf tempLeaf = null;
		if(primaryRoot.getType() != PlaylistNodeType.Leaf) {
			PlaylistNodePrimaryIndex temp = (PlaylistNodePrimaryIndex) primaryRoot;
			while(temp.getChildrenAt(0).getType() != PlaylistNodeType.Leaf) {
				for(i = 0; i < temp.audioIdCount(); i++) {
					if(song.audioId() < temp.audioIdAtIndex(i)) {
						temp = (PlaylistNodePrimaryIndex) temp.getChildrenAt(i);
						break;
					}
				}
				if(i == temp.audioIdCount()) {
					temp = (PlaylistNodePrimaryIndex) temp.getChildrenAt(i);
				}
			}
			for(i = 0; i < temp.audioIdCount(); i++) {
				if(song.audioId() < temp.audioIdAtIndex(i)) {
					tempLeaf = (PlaylistNodePrimaryLeaf) temp.getChildrenAt(i);
					break;
				}
			}
			if(i == temp.audioIdCount()) {
				tempLeaf = (PlaylistNodePrimaryLeaf) temp.getChildrenAt(i);
			}
		}
		else {
			tempLeaf = (PlaylistNodePrimaryLeaf) primaryRoot;
		}
		for(i = 0; i < tempLeaf.songCount(); i++) {
			if(tempLeaf.songAtIndex(i).audioId() > song.audioId()) {
				tempLeaf.addSong(i, song);
				break;
			}
		}
		if(i == tempLeaf.songCount()) {
			tempLeaf.getSongs().add(song);
		}
		if(tempLeaf.songCount() > PlaylistNode.order * 2) {
			primaryLeafPropagation(tempLeaf);
		}


	}

	public void addSecondary(CengSong song) {
		int i;
		PlaylistNodeSecondaryLeaf tempLeaf = null;
		if(secondaryRoot.getType() != PlaylistNodeType.Leaf) {
			PlaylistNodeSecondaryIndex temp = (PlaylistNodeSecondaryIndex) secondaryRoot;
			while(temp.getChildrenAt(0).getType() != PlaylistNodeType.Leaf) {
				for(i = 0; i < temp.genreCount(); i++) {
					if (temp.genreAtIndex(i).compareTo(song.genre()) > 0) {
						temp = (PlaylistNodeSecondaryIndex) temp.getChildrenAt(i);
						break;
					}
					else if(temp.genreAtIndex(i).compareTo(song.genre()) == 0) {
						temp = (PlaylistNodeSecondaryIndex) temp.getChildrenAt(i+1);
						break;
					}
				}
				if(i == temp.genreCount()) {
					tempLeaf = (PlaylistNodeSecondaryLeaf) temp.getChildrenAt(i);
				}
			}
			for(i = 0; i < temp.genreCount(); i++) {
				if (temp.genreAtIndex(i).compareTo(song.genre()) > 0) {
					tempLeaf = (PlaylistNodeSecondaryLeaf) temp.getChildrenAt(i);
					break;
				}
				else if(temp.genreAtIndex(i).compareTo(song.genre()) == 0) {
					tempLeaf = (PlaylistNodeSecondaryLeaf) temp.getChildrenAt(i+1);
					break;
				}
			}
			if(i == temp.genreCount()) {
				tempLeaf = (PlaylistNodeSecondaryLeaf) temp.getChildrenAt(i);
			}
		}
		else {
			tempLeaf = (PlaylistNodeSecondaryLeaf) secondaryRoot;
		}
		for(i = 0; i < tempLeaf.genreCount(); i++) {
			if(tempLeaf.genreAtIndex(i).compareTo(song.genre()) == 0) {
				tempLeaf.addSong(i, song);
				break;
			}
			else if(tempLeaf.genreAtIndex(i).compareTo(song.genre()) > 0) {
				ArrayList<CengSong> newBucket = new ArrayList<CengSong>();
				newBucket.add(song);
				tempLeaf.getSongBucket().add(i, newBucket);
				break;
			}
		}
		if(i == tempLeaf.genreCount()) {
			ArrayList<CengSong> newBucket = new ArrayList<CengSong>();
			newBucket.add(song);
			tempLeaf.getSongBucket().add(i, newBucket);
		}
		if(tempLeaf.genreCount() > PlaylistNode.order * 2) {
			secondaryLeafPropagation(tempLeaf);
		}

		return;
	}

	public PlaylistNodePrimaryIndex primaryLeafPropagation(PlaylistNodePrimaryLeaf leaf) {
		int mid = leaf.songCount() / 2, i = 0;
		ArrayList<CengSong> songsLeft = new ArrayList<CengSong>();
		ArrayList<CengSong> songsRight = new ArrayList<CengSong>();
		PlaylistNodePrimaryIndex parent;
		if(leaf.getParent() == null) {
			ArrayList<Integer> newParentIds = new ArrayList<Integer>();
			ArrayList<PlaylistNode> newParentChildren = new ArrayList<PlaylistNode>();
			parent = new PlaylistNodePrimaryIndex(null, newParentIds, newParentChildren);
			this.primaryRoot = parent;
			PlaylistNodePrimaryLeaf leftChild = new PlaylistNodePrimaryLeaf(parent, songsLeft);
			PlaylistNodePrimaryLeaf rightChild = new PlaylistNodePrimaryLeaf(parent, songsRight);
			for(i = 0; i < mid; i++) {
				songsLeft.add(leaf.getSongs().get(i));
			}
			for(; i < leaf.songCount(); i++) {
				songsRight.add(leaf.getSongs().get(i));
			}
			parent.getAllChildren().add(leftChild);
			parent.getAllChildren().add(rightChild);
			newParentIds.add(leaf.getSongs().get(mid).audioId());
			return parent;
		}
		else {
			parent = (PlaylistNodePrimaryIndex) leaf.getParent();
			PlaylistNodePrimaryLeaf leftChild = new PlaylistNodePrimaryLeaf(parent, songsLeft);
			PlaylistNodePrimaryLeaf rightChild = new PlaylistNodePrimaryLeaf(parent, songsRight);
			for(i = 0; i < mid; i++) {
				songsLeft.add(leaf.getSongs().get(i));
			}
			for(; i < leaf.songCount(); i++) {
				songsRight.add(leaf.getSongs().get(i));
			}
			for(i = 0; i < parent.getAllChildren().size(); i++) {
				if(parent.getChildrenAt(i) == leaf) {
					parent.deleteChild(i);
					break;
				}
			}
			parent.getAllChildren().add(i, leftChild);
			parent.getAllChildren().add(i+1, rightChild);
			parent.addAudioId(i, leaf.getSongs().get(mid).audioId());
			if(parent.audioIdCount() > PlaylistNode.order * 2) {
				primaryIndexPropagation(parent);
			}
			return parent;
		}
	}

	public void primaryIndexPropagation(PlaylistNodePrimaryIndex index) {
		int mid = index.audioIdCount() / 2, i = 0;
		ArrayList<Integer> leftChildIds = new ArrayList<Integer>();
		ArrayList<PlaylistNode> leftChildChildren = new ArrayList<PlaylistNode>();
		ArrayList<Integer> rightChildIds = new ArrayList<Integer>();
		ArrayList<PlaylistNode> rightChildChildren = new ArrayList<PlaylistNode>();
		if(index.getParent() == null) {
			ArrayList<Integer> newAudioIds = new ArrayList<Integer>();
			ArrayList<PlaylistNode> newChildren = new ArrayList<PlaylistNode>();
			PlaylistNodePrimaryIndex newParent = new PlaylistNodePrimaryIndex(null, newAudioIds, newChildren);
			PlaylistNodePrimaryIndex leftChild = new PlaylistNodePrimaryIndex(newParent, leftChildIds, leftChildChildren);
			PlaylistNodePrimaryIndex rightChild = new PlaylistNodePrimaryIndex(newParent, rightChildIds, rightChildChildren);
			newParent.getAllChildren().add(leftChild);
			newParent.getAllChildren().add(rightChild);
			while(i < mid) {
				leftChildChildren.add(index.getAllChildren().get(i));
				index.getChildrenAt(i).setParent(leftChild);
				leftChildIds.add(index.audioIdAtIndex(i));
				i++;
			}
			leftChildChildren.add(index.getAllChildren().get(i));
			index.getChildrenAt(i).setParent(leftChild);
			newParent.addAudioId(0, index.audioIdAtIndex(i));
			i++;
			while(i < index.audioIdCount()) {
				rightChildChildren.add(index.getAllChildren().get(i));
				index.getChildrenAt(i).setParent(rightChild);
				rightChildIds.add(index.audioIdAtIndex(i));
				i++;
			}
			rightChildChildren.add(index.getAllChildren().get(i));
			index.getChildrenAt(i).setParent(rightChild);
			primaryRoot = newParent;
		}
		else {
			int y;
			PlaylistNodePrimaryIndex parent = (PlaylistNodePrimaryIndex) index.getParent();
			PlaylistNodePrimaryIndex tempChild;
			PlaylistNodePrimaryIndex leftChild = new PlaylistNodePrimaryIndex(parent, leftChildIds, leftChildChildren);
			PlaylistNodePrimaryIndex rightChild = new PlaylistNodePrimaryIndex(parent, rightChildIds, rightChildChildren);
			for(y = 0; y < parent.getAllChildren().size(); y++) {
				tempChild = (PlaylistNodePrimaryIndex) parent.getChildrenAt(y);
				if(tempChild == index) {
					parent.deleteChild(y);
					parent.getAllChildren().add(y, leftChild);
					parent.getAllChildren().add(y+1, rightChild);
					break;
				}
			}
			if(y == parent.getAllChildren().size() - 1) {
				parent.addAudioIdLast(index.audioIdAtIndex(mid));
			}
			else {
				parent.addAudioId(y, index.audioIdAtIndex(mid));
			}
			while(i < mid) {
				leftChildChildren.add(index.getChildrenAt(i));
				leftChildIds.add(index.audioIdAtIndex(i));
				index.getChildrenAt(i).setParent(leftChild);
				i++;
			}
			leftChildChildren.add(index.getChildrenAt(i));
			index.getChildrenAt(i).setParent(leftChild);
			i++;
			while(i < index.audioIdCount()) {
				rightChildChildren.add(index.getChildrenAt(i));
				rightChildIds.add(index.audioIdAtIndex(i));
				index.getChildrenAt(i).setParent(rightChild);
				i++;
			}
			rightChildChildren.add(index.getChildrenAt(i));
			index.getChildrenAt(i).setParent(rightChild);
			if(parent.getAllChildren().size() > PlaylistNode.order * 2) {
				primaryIndexPropagation(parent);
			}
		}
	}

	public void secondaryLeafPropagation(PlaylistNodeSecondaryLeaf leaf) {
		int i = 0, mid = leaf.genreCount() / 2;
		ArrayList<ArrayList<CengSong>> leftChildSongs = new ArrayList<ArrayList<CengSong>>();
		ArrayList<ArrayList<CengSong>> rightChildSongs = new ArrayList<ArrayList<CengSong>>();
		if(leaf.getParent() == null) {
			ArrayList<String> newParentGenres = new ArrayList<String>();
			ArrayList<PlaylistNode> newParentChildren = new ArrayList<PlaylistNode>();
			PlaylistNodeSecondaryIndex newParent = new PlaylistNodeSecondaryIndex(null, newParentGenres, newParentChildren);
			PlaylistNodeSecondaryLeaf leftChild = new PlaylistNodeSecondaryLeaf(newParent, leftChildSongs);
			PlaylistNodeSecondaryLeaf rightChild = new PlaylistNodeSecondaryLeaf(newParent, rightChildSongs);
			newParentChildren.add(leftChild);
			newParentChildren.add(rightChild);
			while(i < mid) {
				leftChildSongs.add(leaf.songsAtIndex(i));
				i++;
			}
			newParentGenres.add(leaf.genreAtIndex(i));
			while(i < leaf.genreCount()) {
				rightChildSongs.add(leaf.songsAtIndex(i));
				i++;
			}
			secondaryRoot = newParent;
		}
		else {
			String genreToAdded;
			PlaylistNodeSecondaryIndex parent = (PlaylistNodeSecondaryIndex) leaf.getParent();
			PlaylistNodeSecondaryLeaf leftChild = new PlaylistNodeSecondaryLeaf(parent, leftChildSongs);
			PlaylistNodeSecondaryLeaf rightChild = new PlaylistNodeSecondaryLeaf(parent, rightChildSongs);
			while(i < mid) {
				leftChildSongs.add(leaf.songsAtIndex(i));
				i++;
			}
			genreToAdded = leaf.genreAtIndex(i);
			while(i < leaf.genreCount()) {
				rightChildSongs.add(leaf.songsAtIndex(i));
				i++;
			}
			for(i = 0; i < parent.genreCount(); i++) {
				if(parent.genreAtIndex(i).compareTo(genreToAdded) > 0) {
					parent.genreAdd(i, genreToAdded);
					break;
				}
			}
			if(i == parent.genreCount()) {
				parent.genreAdd(i, genreToAdded);
			}
			for(i = 0; i < parent.getAllChildren().size(); i++) {
				if(parent.getChildrenAt(i) == leaf) {
					break;
				}
			}
			parent.getAllChildren().remove(i);
			parent.getAllChildren().add(i, leftChild);
			parent.getAllChildren().add(i+1, rightChild);
			if(parent.genreCount() > PlaylistNode.order * 2) {
				secondaryIndexPropagation(parent);
			}
		}
	}

	public void secondaryIndexPropagation(PlaylistNodeSecondaryIndex index) {
		int i = 0, mid = index.genreCount() / 2;
		ArrayList<String> leftChildGenres = new ArrayList<String>();
		ArrayList<String> rightChildGenres = new ArrayList<String>();
		ArrayList<PlaylistNode> leftChildChildren = new ArrayList<PlaylistNode>();
		ArrayList<PlaylistNode> rightChildChildren = new ArrayList<PlaylistNode>();
		if(index.getParent() == null) {
			ArrayList<String> newParentGenres = new ArrayList<String>();
			ArrayList<PlaylistNode> newParentChildren = new ArrayList<PlaylistNode>();
			PlaylistNodeSecondaryIndex newParent = new PlaylistNodeSecondaryIndex(null, newParentGenres, newParentChildren);
			PlaylistNodeSecondaryIndex leftChild = new PlaylistNodeSecondaryIndex(newParent, leftChildGenres, leftChildChildren);
			PlaylistNodeSecondaryIndex rightChild = new PlaylistNodeSecondaryIndex(newParent, rightChildGenres, rightChildChildren);
			newParentChildren.add(leftChild);
			newParentChildren.add(rightChild);
			while(i < mid) {
				leftChildGenres.add(index.genreAtIndex(i));
				leftChildChildren.add(index.getChildrenAt(i));
				index.getChildrenAt(i).setParent(leftChild);
				i++;
			}
			leftChildChildren.add(index.getChildrenAt(i));
			index.getChildrenAt(i).setParent(leftChild);
			newParentGenres.add(index.genreAtIndex(i));
			i++;
			while(i < index.genreCount()) {
				rightChildGenres.add(index.genreAtIndex(i));
				rightChildChildren.add(index.getChildrenAt(i));
				index.getChildrenAt(i).setParent(rightChild);
				i++;
			}
			rightChildChildren.add(index.getChildrenAt(i));
			index.getChildrenAt(i).setParent(rightChild);
			secondaryRoot = newParent;
		}
		else {
			String genreToAdded;
			PlaylistNodeSecondaryIndex parent = (PlaylistNodeSecondaryIndex) index.getParent(), tempChild;
			PlaylistNodeSecondaryIndex leftChild = new PlaylistNodeSecondaryIndex(parent, leftChildGenres, leftChildChildren);
			PlaylistNodeSecondaryIndex rightChild = new PlaylistNodeSecondaryIndex(parent, rightChildGenres, rightChildChildren);
			while(i < parent.getAllChildren().size()) {
				tempChild = (PlaylistNodeSecondaryIndex) parent.getChildrenAt(i);
				if(tempChild == index) {
					parent.getAllChildren().remove(i);
					parent.getAllChildren().add(i, leftChild);
					parent.getAllChildren().add(i+1, rightChild);
					break;
				}
				i++;
			}
			for(i = 0; i < mid; i++) {
				leftChildGenres.add(index.genreAtIndex(i));
				leftChildChildren.add(index.getChildrenAt(i));
				index.getChildrenAt(i).setParent(leftChild);
			}
			genreToAdded = index.genreAtIndex(i);
			i++;
			for(; i < index.genreCount(); i++) {
				rightChildGenres.add(index.genreAtIndex(i));
				rightChildChildren.add(index.getChildrenAt(i));
				index.getChildrenAt(i).setParent(rightChild);
			}
			rightChildChildren.add(index.getChildrenAt(i));
			index.getChildrenAt(i).setParent(rightChild);
			for(i = 0; i < parent.genreCount(); i++) {
				if(genreToAdded.compareTo(parent.genreAtIndex(i)) > 0) {
					parent.genreAdd(i, genreToAdded);
					break;
				}
			}
			if(parent.genreCount() > PlaylistNode.order * 2) {
				secondaryIndexPropagation(parent);
			}
		}
	}

	public void printPrimaryDFS(PlaylistNode root, int tabCount) {
		int i, j;
		String toPrint = "";
		if(root.getType() == PlaylistNodeType.Leaf) {
			PlaylistNodePrimaryLeaf rootLeaf = (PlaylistNodePrimaryLeaf) root;
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("<data>\n");
			for(i = 0; i < rootLeaf.songCount(); i++) {
				for(j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat("<record>" + rootLeaf.songAtIndex(i).audioId() + "|" + rootLeaf.songAtIndex(i).genre() + "|" + rootLeaf.songAtIndex(i).songName() + "|" + rootLeaf.songAtIndex(i).artist() + "</record>\n");
			}
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("</data>");
			System.out.println(toPrint);
		}
		else {
			PlaylistNodePrimaryIndex rootIndexed = (PlaylistNodePrimaryIndex) root;
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("<index>\n");
			for(i = 0; i < rootIndexed.audioIdCount(); i++) {
				for(j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat(Integer.toString(rootIndexed.audioIdAtIndex(i)) + "\n");
			}
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("</index>");
			System.out.println(toPrint);
			tabCount++;
			for(i = 0; i < rootIndexed.getAllChildren().size(); i++) {
				printPrimaryDFS(rootIndexed.getChildrenAt(i), tabCount);
			}
		}
	}

	public void printSecondaryDFS(PlaylistNode root, int tabCount) {
		int i, j, k;
		String toPrint = "";
		CengSong tempSong;
		if(root.getType() == PlaylistNodeType.Leaf) {
			PlaylistNodeSecondaryLeaf rootLeaf = (PlaylistNodeSecondaryLeaf) root;
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("<data>\n");
			for(i = 0; i < rootLeaf.genreCount(); i++) {
				for(j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat(rootLeaf.genreAtIndex(i) + "\n");

				for(j = 0; j < rootLeaf.getSongBucket().get(i).size(); j++) {
					for(k = 0; k < tabCount + 1; k++) {
						toPrint = toPrint.concat("\t");
					}
					tempSong = rootLeaf.getSongBucket().get(i).get(j);
					toPrint = toPrint.concat("<record>" + tempSong.audioId() + "|" + tempSong.genre() + "|" + tempSong.songName() + "|" + tempSong.artist() + "</record>\n");

				}
			}
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("</data>");
			System.out.println(toPrint);
		}
		else {
			PlaylistNodeSecondaryIndex rootIndexed = (PlaylistNodeSecondaryIndex) root;
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("<index>\n");
			for(i = 0; i < rootIndexed.genreCount(); i++) {
				for(j = 0; j < tabCount; j++) {
					toPrint = toPrint.concat("\t");
				}
				toPrint = toPrint.concat(rootIndexed.genreAtIndex(i) + "\n");
			}
			for(j = 0; j < tabCount; j++) {
				toPrint = toPrint.concat("\t");
			}
			toPrint = toPrint.concat("</index>");
			System.out.println(toPrint);
			tabCount++;
			for(i = 0; i < rootIndexed.getAllChildren().size(); i++) {
				printSecondaryDFS(rootIndexed.getChildrenAt(i), tabCount);
			}
		}
	}

}
